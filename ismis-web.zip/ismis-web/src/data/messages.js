
let messages = [
    {   
        id: 1,
        name: "Jasmin Owacan",
        office: "OFFICE OF STUDENT FORMATION AND ACTIVITIES",
        date: "Monday, September 2, 2024 11:40 AM",
        subject: "TO ALL NEW STUDENTS",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
    },
    {
        id: 2,
        name: "Elijah Abangan",
        office: "STUDENT COUNCIL",
        date: "Monday, September 2, 2024 11:40 AM",
        subject: "goofy ahh mf",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"
    },
    {
        id: 3,
        name: "Keenan Mendiola",
        office: "DEPARTMENT OF COMPUTER INFORMATION SCIENCES AND MATHEMATICS",
        date: "Monday, September 2, 2024 11:40 AM",
        subject: "WEB DEV 2",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"
    },
]

export default messages