
const Footer = () => {
    return (
        <>
            <footer className="bg-usc-green flex text-white p-8" >2024 © UNIVERSITY OF SAN CARLOS - ISMIS Version 2.0</footer>
        </>
    )
}

export default Footer