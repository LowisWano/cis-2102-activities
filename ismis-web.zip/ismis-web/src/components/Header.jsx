
const Header = () => {
    return (
        <>
            <header className='p-3' >
                <img className="h-11" src="/usc-header.png" alt="usc logo" />
            </header>
        </>
    )
}

export default Header