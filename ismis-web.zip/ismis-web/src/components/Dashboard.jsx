import Contents from "./Contents"

const Dashboard = () => {
    return (
        <> 
            <Contents/>
            
        </>
    )
}

export default Dashboard