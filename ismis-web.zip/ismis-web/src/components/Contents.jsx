import Announcements from './Announcements'

const Contents = () => {
    return(
        <>
          <Announcements/>
        </>
    )
}

export default Contents